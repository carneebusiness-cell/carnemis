import { getStore } from "@netlify/blobs";

const headers = {
  "content-type": "application/json",
  "access-control-allow-origin": "*",
  "access-control-allow-methods": "GET,PUT,OPTIONS",
  "access-control-allow-headers": "Content-Type"
};

export default async (request) => {
  if (request.method === "OPTIONS") return new Response("", { headers });
  const token = new URL(request.url).searchParams.get("token") || "";
  if (!token || token.length < 16) return new Response(JSON.stringify({ error: "Missing shop token" }), { status: 400, headers });
  const store = getStore("carne-books");
  if (request.method === "PUT" || request.method === "POST") {
    const body = await request.text();
    await store.set(token, body);
    return new Response(JSON.stringify({ ok: true }), { headers });
  }
  const saved = await store.get(token, { type: "text" });
  return new Response(saved || "{}", { headers });
};
